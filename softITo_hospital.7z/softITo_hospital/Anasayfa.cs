﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace softITo_hospital
{
	public partial class Anasayfa : Form
	{
		db_hospitalEntities con = new db_hospitalEntities();
		public Anasayfa()
		{
			InitializeComponent();
			this.BackgroundImage = Image.FromFile(@"C:\Users\LENOVO\Desktop\WhatsApp Görsel 2025-06-01 saat 18.29.15_068c3e80.jpg");
			this.BackgroundImageLayout = ImageLayout.Stretch;
		}

		private void sekreterGirişiToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string KullaniciAdi = textBox1.Text;
			string FirstName = "";
			string LastName = "";

			if (!KullaniciAdi.Contains("_"))
			{
				MessageBox.Show("Kullanıcı adı '_' karakteri içermelidir.");
				return;
			}

			FirstName = KullaniciAdi.Split('_')[0];
			LastName = KullaniciAdi.Split('_')[1];
			string Password = textBox2.Text;

			var result = con.sp_GetInfoSecretaryByCredentials(FirstName, LastName, Password).FirstOrDefault();


			if (result != null)
			{
				MessageBox.Show("Giriş başarılı: " + result.Firstname + result.Lastname);
				MessageBox.Show(" Lütfen Bekleyiniz Anasayfanıza Yönlendiriliyorsunuz...........");
				Sekreter_İşlemleri sekreter_İşlemleri = new Sekreter_İşlemleri();
				sekreter_İşlemleri.Show();
				this.Hide();
			}
			else
			{
				MessageBox.Show("Kullanıcı bulunamadı.");
				MessageBox.Show("Anasayfaya Yönlendiriliyorsunuz");
				// otomotik yönlendirebilir misşn

			}
			

		}

		private void doktorGirişiToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string KullaniciAdi = textBox1.Text;
			string FirstName = "";
			string LastName = "";

			if (!KullaniciAdi.Contains("_"))
			{
				MessageBox.Show("Kullanıcı adı '_' karakteri içermelidir.");
				return;
			}

			FirstName = KullaniciAdi.Split('_')[0];
			LastName = KullaniciAdi.Split('_')[1];
			string Password = textBox2.Text;

			var result = con.sp_GetInfoDoctorByCredentials(FirstName, LastName, Password).FirstOrDefault();

			if (result != null)
			{
				MessageBox.Show("Giriş başarılı: " + result.Firstname + result.Lastname);
				MessageBox.Show(" Lütfen Bekleyiniz İlgili Sayafanıza  Yönlendiriliyorsunuz...........");
				Doktor_İşlemleri doktor_islemleri = new Doktor_İşlemleri();
				doktor_islemleri.Show();
				this.Hide();
			}
			else
			{
				MessageBox.Show("Kullanıcı bulunamadı.");
			}

		}


	}
}
