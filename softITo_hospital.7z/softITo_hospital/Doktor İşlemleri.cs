﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace softITo_hospital
{
	public partial class Doktor_İşlemleri : Form
	{
		public Doktor_İşlemleri()
		{
			InitializeComponent();
		}

		private void Doktor_İşlemleri_Load(object sender, EventArgs e)
		{

			comboBox1.Items.Add("Doktor Hasta Sayısı");
			comboBox1.Items.Add("En Sık Yazılan İlaçlar");
			comboBox1.Items.Add("Hasta Başına Ortalama Reçete");
			comboBox1.Items.Add("Günlük Hasta Kaydı");
			comboBox1.Items.Add("Radyoloji Görüntü Tipleri");
			comboBox1.Items.Add("Doktorların Tedavi Sayısı");
			comboBox1.Items.Add("Lab Test Raporları");
			comboBox1.Items.Add("En Aktif Doktorlar");
			comboBox1.Items.Add("Hasta Acil Durum Bilgileri");
			comboBox1.Items.Add("Yaşa Göre Hasta Grupları");


		}


		private void button5_Click(object sender, EventArgs e)
		{
			Anasayfa anasayfa = new Anasayfa();
			anasayfa.Show();
			this.Hide();
		}
		private void button2_Click(object sender, EventArgs e)
		{
			TeshisTedaviReceteIslemleri tsti = new TeshisTedaviReceteIslemleri();
			tsti.Show();
			this.Hide();
		}

	

		private void button3_Click(object sender, EventArgs e)
		{
			HastaTıbiTakip hastaTıbiTakip = new HastaTıbiTakip();
			hastaTıbiTakip.Show();
			this.Hide();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			HastaTıbiTakip hastaTıbiTakip = new HastaTıbiTakip();
			hastaTıbiTakip.Show();
			this.Hide();
		}

		private void button6_Click(object sender, EventArgs e)
		{

			string connectionString = "Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true";
			string query = "";

			switch (comboBox1.SelectedItem.ToString())
			{
				case "Doktor Hasta Sayısı":
					query = @"
                SELECT d.FirstName + ' ' + d.LastName AS DoctorName, COUNT(m.RecordId) AS TotalPatients
                FROM Doctors d
                JOIN MedicalRecords m ON d.DoctorId = m.DoctorId
                GROUP BY d.FirstName, d.LastName
                HAVING COUNT(m.RecordId) > 0";
					break;

				case "En Sık Yazılan İlaçlar":
					query = @"
                SELECT MedicineName, COUNT(*) AS UsageCount
                FROM Prescriptions
                GROUP BY MedicineName
                ORDER BY UsageCount DESC";
					break;

				case "Hasta Başına Ortalama Reçete":
					query = @"
                SELECT p.FirstName + ' ' + p.LastName AS PatientName, COUNT(pr.PrescriptionId) AS PrescriptionCount
                FROM Patients p
                JOIN MedicalRecords m ON p.PatientId = m.PatientId
                JOIN Prescriptions pr ON m.RecordId = pr.RecordId
                GROUP BY p.FirstName, p.LastName
                HAVING COUNT(pr.PrescriptionId) > 1";
					break;

				case "Günlük Hasta Kaydı":
					query = @"
                SELECT CONVERT(date, RecordDate) AS RecordDay, COUNT(*) AS CountPerDay
                FROM MedicalRecords
                GROUP BY CONVERT(date, RecordDate)";
					break;

				case "Radyoloji Görüntü Tipleri":
					query = @"
                SELECT ImageType, COUNT(*) AS Total
                FROM RadiologyImages
                GROUP BY ImageType";
					break;

				case "Doktorların Tedavi Sayısı":
					query = @"
                SELECT d.FirstName + ' ' + d.LastName AS DoctorName, COUNT(m.Treatment) AS TreatmentCount
                FROM Doctors d
                JOIN MedicalRecords m ON d.DoctorId = m.DoctorId
                GROUP BY d.FirstName, d.LastName";
					break;

				case "Lab Test Raporları":
					query = @"
                SELECT TestName, AVG(CAST(ResultValue AS FLOAT)) AS AvgResult
                FROM LabResults
                GROUP BY TestName";
					break;

				case "En Aktif Doktorlar":
					query = @"
                SELECT d.FirstName + ' ' + d.LastName AS DoctorName, COUNT(*) AS TotalAppointments
                FROM MedicalRecords m
                JOIN Doctors d ON m.DoctorId = d.DoctorId
                GROUP BY d.FirstName, d.LastName
                ORDER BY TotalAppointments DESC";
					break;

				case "Hasta Acil Durum Bilgileri":
					query = @"
                SELECT FirstName, LastName, EmergencyContactName, EmergencyPhone
                FROM Patients
                WHERE EmergencyContactName IS NOT NULL";
					break;

				case "Yaşa Göre Hasta Grupları":
					query = @"
                SELECT 
                    CASE 
                        WHEN DATEDIFF(YEAR, DateOfBirth, GETDATE()) BETWEEN 0 AND 18 THEN '0-18'
                        WHEN DATEDIFF(YEAR, DateOfBirth, GETDATE()) BETWEEN 19 AND 40 THEN '19-40'
                        WHEN DATEDIFF(YEAR, DateOfBirth, GETDATE()) BETWEEN 41 AND 60 THEN '41-60'
                        ELSE '60+'
                    END AS AgeGroup,
                    COUNT(*) AS Count
                FROM Patients
                GROUP BY 
                    CASE 
                        WHEN DATEDIFF(YEAR, DateOfBirth, GETDATE()) BETWEEN 0 AND 18 THEN '0-18'
                        WHEN DATEDIFF(YEAR, DateOfBirth, GETDATE()) BETWEEN 19 AND 40 THEN '19-40'
                        WHEN DATEDIFF(YEAR, DateOfBirth, GETDATE()) BETWEEN 41 AND 60 THEN '41-60'
                        ELSE '60+'
                    END";
					break;

				default:
					MessageBox.Show("Lütfen geçerli bir sorgu seçin.");
					return;
			}

			using (SqlConnection con = new SqlConnection(connectionString))
			{
				SqlDataAdapter da = new SqlDataAdapter(query, con);
				DataTable dt = new DataTable();
				da.Fill(dt);
				dataGridView1.DataSource = dt;
			}
		

	}

		private void button1_Click(object sender, EventArgs e)
		{
			string mesaj = textBox1.Text;
			if(mesaj.Length != 0)
			{
				MessageBox.Show($"{mesaj}'nız sekretere gönderilmiştir");
			}
			else
			{
				MessageBox.Show($"{mesaj}'nız Boş tekrar sekretere gönderilmemiştir");
			}
		}
	}
}
