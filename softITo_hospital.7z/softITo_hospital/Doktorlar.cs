﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace softITo_hospital
{
	public partial class Doktorlar : Form
	{
		db_hospitalEntities con = new db_hospitalEntities();
		public Doktorlar()
		{
			InitializeComponent();
			this.BackgroundImage = Image.FromFile(@"C:\Users\LENOVO\Desktop\WhatsApp Görsel 2025-06-01 saat 18.49.32_7dfb7ec6.jpg");
			this.BackgroundImageLayout = ImageLayout.Stretch;
			
		}

		private void button1_Click(object sender, EventArgs e)
		{
			dataGridView1.DataSource = con.DoktorListele();
			//con.SaveChanges();veri tabanına yansıltılamsı gerekn bir değişiklik yok burda gereksiz.

		}

		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0) 
			{ 
			DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
			textBox1.Text = row.Cells["DoctorId"].Value.ToString();
			textBox2.Text = row.Cells["FirstName"].Value.ToString();
			textBox3.Text = row.Cells["LastName"].Value.ToString();
			textBox4.Text = row.Cells["Specialty"].Value.ToString();
			textBox5.Text = row.Cells["Email"].Value.ToString();
			textBox6.Text = row.Cells["PhoneNumber"].Value.ToString();
			textBox7.Text = row.Cells["RoomNumber"].Value.ToString();
			

			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Doctor doctor = new Doctor();
			doctor.FirstName = textBox2.Text;
			doctor.LastName = textBox3.Text;
			doctor.Specialty = textBox4.Text;
			doctor.Email = textBox5.Text;
			doctor.PhoneNumber = textBox6.Text;
			doctor.RoomNumber = textBox7.Text;
			con.sp_DoktorEkle(doctor.FirstName, doctor.LastName, doctor.Specialty, doctor.Email, doctor.PhoneNumber, doctor.RoomNumber);
			con.SaveChanges();
			dataGridView1.DataSource = con.DoktorListele();
		}

		private void button3_Click(object sender, EventArgs e)
		{


			Doctor doctor = new Doctor();
			doctor.DoctorId =Convert.ToInt32(textBox1.Text);
			doctor.FirstName = textBox2.Text;
			doctor.LastName = textBox3.Text;
			doctor.Specialty = textBox4.Text;
			doctor.Email = textBox5.Text;
			doctor.PhoneNumber = textBox6.Text;
			doctor.RoomNumber = textBox7.Text;
			con.sp_DoktorGüncelle(doctor.DoctorId,doctor.FirstName, doctor.LastName, doctor.Specialty, doctor.Email, doctor.PhoneNumber, doctor.RoomNumber);
			con.SaveChanges();
			dataGridView1.DataSource = con.DoktorListele();


		}

		private void button4_Click(object sender, EventArgs e)
		{
			Doctor doctor = new Doctor();
			doctor.DoctorId = Convert.ToInt32(textBox1.Text);
			con.sp_DoktorSil(doctor.DoctorId);
		}

		private void button5_Click(object sender, EventArgs e)
		{
			foreach (Control control in this.Controls)
			{
				if (control is TextBox)
				{
					((TextBox)control).Clear();
				}
			}

		}

		private void button6_Click(object sender, EventArgs e)
		{
			Sekreter_İşlemleri sekreter_İşlemleri = new Sekreter_İşlemleri();
			sekreter_İşlemleri.Show();
			this.Hide();
		}
	}

}
