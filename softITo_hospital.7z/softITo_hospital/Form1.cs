﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace softITo_hospital
{
	public partial class Form1 : Form
	{

		db_hospitalEntities con = new db_hospitalEntities();
		public Form1()
		{
			InitializeComponent();
		}
		private void button1_Click(object sender, EventArgs e)
		{
			dataGridView1.DataSource = con.GetAppointmentDetails(); // Yeniden yükle
			MessageBox.Show("merhaba");
			foreach (DataGridViewColumn col in dataGridView1.Columns)
			{
				MessageBox.Show(col.Name);
			}

		
			


		}
		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			
		}
	}
}
