﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace softITo_hospital
{
	public partial class HastaTıbiTakip : Form
	{
		db_hospitalEntities con = new  db_hospitalEntities();
		public HastaTıbiTakip()
		{
			InitializeComponent();
			this.BackgroundImage = Image.FromFile(@"C:\Users\LENOVO\Desktop\WhatsApp Görsel 2025-06-01 saat 18.44.35_861caeea.jpg");
			this.BackgroundImageLayout = ImageLayout.Stretch;
			
		}

		private void HastaTıbiTakip_Load(object sender, EventArgs e)
		{

			comboBox1.Items.Clear();
			comboBox1.Items.Add("Test");
			comboBox1.Items.Add("Kan");
			comboBox1.Items.Add("İdrar");
			comboBox1.Items.Add("Röntgen");
			comboBox1.Items.Add("Ultrason");
			comboBox1.Items.Add("Tansiyon");

			lvRadiology.Columns.Add("Hasta", 100);
			lvRadiology.Columns.Add("Doktor", 100);
			lvRadiology.Columns.Add("Tür", 80);
			lvRadiology.Columns.Add("Görüntü Adı", 100);
			lvRadiology.Columns.Add("Tarih", 100);
			lvRadiology.Columns.Add("Açıklama", 150);
			lvRadiology.View = View.Details;
			lvRadiology.FullRowSelect = true;


		}

		private void button1_Click(object sender, EventArgs e)
		{

			string firstName = textBox1.Text.Trim();
			string lastName = textBox1.Text.Trim();
			string testName = comboBox1.SelectedItem?.ToString();

			if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName) || string.IsNullOrEmpty(testName))
			{
				MessageBox.Show("Lütfen tüm bilgileri doldurun.");
				return;
			}

			// Prosedürü çağır
			var results = con.sp_GetLabResultsByTest(testName, firstName, lastName);

			// Sonuçları bir DataGridView'e yükle
			dataGridView2.DataSource = results.ToList();
		}

		private void button4_Click(object sender, EventArgs e)
		{

			var result = con.GetPatientLastRecords().ToList();
			dataGridView2.DataSource = result;

		}
		private void button3_Click(object sender, EventArgs e)
		{
			int patientId;

			if (!int.TryParse(textBox3.Text.Trim(), out patientId))
			{
				MessageBox.Show("Lütfen geçerli bir hasta ID giriniz.");
				return;
			}

			using (db_hospitalEntities con = new db_hospitalEntities())
			{
				try
				{
					var result = con.GetPatientRadiologyImages(patientId).ToList();

					lvRadiology.Items.Clear();

					foreach (var item in result)
					{
						ListViewItem lvi = new ListViewItem(item.PatientName); // 1. sütun
						lvi.SubItems.Add(item.DoctorName);                    // 2. sütun
						lvi.SubItems.Add(item.ImageType);                     // 3. sütun
						lvi.SubItems.Add(item.ImageName);                     // 4. sütun
						lvi.SubItems.Add(item.CaptureDate.HasValue ? item.CaptureDate.Value.ToShortDateString(): "");
						// 5. sütun
						lvi.SubItems.Add(item.Description);                   // 6. sütun

						lvRadiology.Items.Add(lvi);
					}

					if (result.Count == 0)
					{
						MessageBox.Show("Bu hasta için radyoloji kaydı bulunamadı.");
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show("Hata: " + ex.Message);
				}
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Anasayfa anasayfa = new Anasayfa();
			anasayfa.Show();
			this.Hide();
		}
	}
}
