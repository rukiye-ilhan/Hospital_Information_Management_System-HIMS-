﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace softITo_hospital
{
	public partial class Hastalar : Form
	{
		db_hospitalEntities con = new db_hospitalEntities();
		public Hastalar()
		{
			InitializeComponent();
			
			this.BackgroundImage = Image.FromFile(@"C:\Users\LENOVO\Desktop\WhatsApp Görsel 2025-06-01 saat 18.46.56_2c2426e0.jpg");
			this.BackgroundImageLayout = ImageLayout.Stretch;
		}

		private void button4_Click(object sender, EventArgs e)
		{
			dataGridView1.DataSource = con.sp_GetAllPatients();

			/*foreach (DataGridViewColumn column in dataGridView1.Columns)
			{
				MessageBox.Show(column.Name);
			}*/


		}
		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0)
			{
				DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
				textBox0.Text = row.Cells["PatientId"].Value.ToString();
				textBox1.Text = row.Cells["FirstName"].Value.ToString();
				textBox2.Text = row.Cells["LastName"].Value.ToString();
				textBox3.Text = row.Cells["DateOfBirth"].Value.ToString();
				textBox4.Text = row.Cells["Address"].Value.ToString();
				textBox6.Text = row.Cells["Email"].Value.ToString();
				textBox7.Text = row.Cells["EmergencyContactName"].Value.ToString();
				textBox8.Text = row.Cells["EmergencyPhone"].Value.ToString();
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Patient patient = new Patient();
			patient.FirstName = textBox1.Text;
			patient.LastName = textBox2.Text;
			patient.DateOfBirth = DateTime.Parse(textBox3.Text);
			patient.Address = textBox4.Text;	
			patient.Email = textBox6.Text;
			patient.EmergencyContactName = textBox7.Text;	
			patient.EmergencyPhone = textBox8.Text;
			con.sp_AddPatients(patient.FirstName,patient.LastName,patient.DateOfBirth,patient.Address,patient.Email,patient.EmergencyContactName,patient.EmergencyPhone);
			con.SaveChanges();
			dataGridView1.DataSource = con.sp_GetAllPatients();




		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				Patient patient = new Patient();
				patient.PatientId = Convert.ToInt32(textBox0.Text);
				patient.FirstName = textBox1.Text;
				patient.LastName = textBox2.Text;
				patient.DateOfBirth = DateTime.Parse(textBox3.Text);
				patient.Address = textBox4.Text;
				patient.Email = textBox6.Text;
				patient.EmergencyContactName = textBox7.Text;
				patient.EmergencyPhone = textBox8.Text;

				con.sp_UpdatePatient(
					patient.PatientId,
					patient.FirstName,
					patient.LastName,
					patient.DateOfBirth,
					patient.Address,
					patient.Email,
					patient.EmergencyContactName,
					patient.EmergencyPhone
				);

				con.SaveChanges();
				dataGridView1.DataSource = con.sp_GetAllPatients().ToList();
				MessageBox.Show("Hasta bilgileri güncellendi.");
			}
			catch (Exception ex)
			{
				MessageBox.Show("Hata: " + ex.Message);
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try{

				Patient patient = new Patient();
				patient.PatientId = Convert.ToInt32(textBox0.Text);
				con.sp_DeletePatient(patient.PatientId);
				con.SaveChanges();
				dataGridView1.DataSource = con.sp_GetAllPatients();
				MessageBox.Show("Hasta Silindi");
				textBox0.Clear();
				textBox1.Clear();
				textBox2.Clear();
				textBox3.Clear();
				textBox4.Clear();
				textBox6.Clear();
				textBox7.Clear();
				textBox8.Clear();
			}

			catch (Exception ex)
			{
				MessageBox.Show("hata" + ex);
			}
			



		}

		private void button5_Click(object sender, EventArgs e)
		{
				Sekreter_İşlemleri sekreter_İşlemleri = new Sekreter_İşlemleri();
				sekreter_İşlemleri.Show();
				this.Hide();
		}

		private void button6_Click(object sender, EventArgs e)
		{
			foreach (Control control in this.Controls)
			{
				if (control is TextBox)
				{
					((TextBox)control).Clear();
				}
			}

		}
	}
}
