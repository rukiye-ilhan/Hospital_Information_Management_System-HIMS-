﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace softITo_hospital
{
	public partial class Randevuler : Form
	{
		db_hospitalEntities con = new db_hospitalEntities();
		public Randevuler()
		{
			InitializeComponent();
			this.BackgroundImage = Image.FromFile(@"C:\Users\LENOVO\Desktop\WhatsApp Görsel 2025-06-01 saat 19.09.17_d1a4d41d.jpg");
			this.BackgroundImageLayout = ImageLayout.Stretch;
			
		}
		private void Randevuler_Load(object sender, EventArgs e)
		{
			var doktorlar = con.DoktorIsimListele().ToList();
			// ComboBox'a veri bağlama
			comboBox1.DataSource = doktorlar;
			comboBox1.DisplayMember = "FullName"; // Bunu oluşturacağız
			comboBox1.ValueMember = "DoctorId";


		}

		private void button1_Click(object sender, EventArgs e)
		{
			// 1. ComboBox'tan doktor adı-soyadı al
			string[] fullName = comboBox1.Text.Split(' ');
			if (fullName.Length < 2)
			{
				MessageBox.Show("Lütfen geçerli bir doktor adı-soyadı seçiniz.");
				return;
			}

			string firstName = fullName[0];
			string lastName = fullName[1];

			// 2. Tarihi al (sadece tarih kısmı kullanılacak)
			DateTime selectedDate = dateTimePicker1.Value.Date;

			// 3. Stored procedure çağır
			var result = con.sp_GetPatientCountByDoctorAndDate(firstName, lastName, selectedDate).ToList();

			// 4. DataGridView'e aktar
			dataGridView1.DataSource = result;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			var sonuc = con.GetPatientsOver65().ToList();
			dataGridView2.DataSource = sonuc;
		}


		private void button3_Click(object sender, EventArgs e)
		{
			MessageBox.Show("merhaba");
			foreach (DataGridViewColumn col in dataGridView3.Columns)
			{
				MessageBox.Show(col.Name);
			}

			dataGridView3.DataSource = null; // Önce temizle
			dataGridView3.AutoGenerateColumns = true; // Otomatik sütun oluşturmayı aç
			dataGridView3.DataSource = con.GetAppointmentDetails(); // Yeniden yükle
			

		}

		private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
		{
		}

		private void dataGridView3_CellClick_1(object sender, DataGridViewCellEventArgs e)
		{

			if (e.RowIndex >= 0)
			{
				DataGridViewRow row = dataGridView3.Rows[e.RowIndex];
				//textBox1.Text = row.Cells["AppointmentId"].Value.ToString();
				//int id = Convert.ToInt32(row.Cells["DoctorName"].Value);
				//var result = con.GetNameDoctorById(id).FirstOrDefault();
				textBox4.Text = row.Cells["DoctorName"].Value.ToString();
				//int id_1 = Convert.ToInt32(row.Cells["PatientId"].Value);
				//var result_1 = con.GetNamePatientById(id_1).FirstOrDefault();
				textBox6.Text = row.Cells["PatientName"].Value.ToString(); ;
				textBox5.Text = row.Cells["Specialty"].Value.ToString();
				dateTimePicker1.Value = Convert.ToDateTime(row.Cells["AppointmentDate"].Value);
				dateTimePicker2.Value = Convert.ToDateTime(row.Cells["CreatedAt"].Value);
				textBox3.Text = row.Cells["Notes"].Value.ToString();
				
			}

		}


		private void button4_Click(object sender, EventArgs e)
		{

			string patientName = textBox6.Text.Trim();
			string doctorName = textBox4.Text.Trim();
			DateTime appointmentDate = dateTimePicker1.Value;
			string notes = textBox3.Text;

			// Hasta ID'sini al
			var patientId = con.Patients
				.Where(p => (p.FirstName + " " + p.LastName) == patientName)
				.Select(p => p.PatientId)
				.FirstOrDefault();

			// Doktor ID'sini al
			var doctorId = con.Doctors
				.Where(d => (d.FirstName + " " + d.LastName) == doctorName)
				.Select(d => d.DoctorId)
				.FirstOrDefault();

			if (patientId == 0 || doctorId == 0)
			{
				MessageBox.Show("Hasta veya doktor bulunamadı.");
				return;
			}

			// Randevu ekle
			con.sp_AddAppointment(patientId, doctorId, appointmentDate, notes);
			con.SaveChanges();
			dataGridView3.DataSource = con.GetAppointmentDetails();

			MessageBox.Show("Randevu başarıyla oluşturuldu.");
		}

		private void button5_Click(object sender, EventArgs e)
		{
			string patientName = textBox6.Text.Trim();
			string doctorName = textBox4.Text.Trim();
			DateTime appointmentDate = dateTimePicker1.Value;
			string notes = textBox3.Text;
			int AppointmentId = Convert.ToInt32(textBox1.Text);

			// Hasta ID'sini al
			var patientId = con.Patients
				.Where(p => (p.FirstName + " " + p.LastName) == patientName)
				.Select(p => p.PatientId)
				.FirstOrDefault();

			// Doktor ID'sini al
			var doctorId = con.Doctors
				.Where(d => (d.FirstName + " " + d.LastName) == doctorName)
				.Select(d => d.DoctorId)
				.FirstOrDefault();

			if (patientId == 0 || doctorId == 0)
			{
				MessageBox.Show("Hasta veya doktor bulunamadı.");
				return;
			}
			// Randevu ekle
			con.sp_UpdateAppointment(AppointmentId,patientId, doctorId, appointmentDate, notes);
			con.SaveChanges();
			dataGridView3.DataSource = con.GetAppointmentDetails();

			MessageBox.Show("Randevu başarıyla oluşturuldu.");

		}

		private void button6_Click(object sender, EventArgs e)
		{
			int AppointmentId = Convert.ToInt32(textBox1.Text);
			con.sp_DeleteAppointment(AppointmentId);
			con.SaveChanges();
			dataGridView3.DataSource = con.GetAppointmentDetails();

		}



			private void button7_Click(object sender, EventArgs e)
		{
			Sekreter_İşlemleri sekreter_İşlemleri = new Sekreter_İşlemleri();
			sekreter_İşlemleri.Show();
			this.Hide();
		}






















		private void label7_Click(object sender, EventArgs e)
		{

		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{

		}

		private void groupBox3_Enter(object sender, EventArgs e)
		{

		}

	
	}
}
