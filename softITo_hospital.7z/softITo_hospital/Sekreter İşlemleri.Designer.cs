﻿namespace softITo_hospital
{
	partial class Sekreter_İşlemleri
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.pictureBox5 = new System.Windows.Forms.PictureBox();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.button6 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			this.button8 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.button10 = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.label7 = new System.Windows.Forms.Label();
			this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
			this.button11 = new System.Windows.Forms.Button();
			this.button12 = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.label8 = new System.Windows.Forms.Label();
			this.button13 = new System.Windows.Forms.Button();
			this.Mesaj = new System.Windows.Forms.ListBox();
			this.button14 = new System.Windows.Forms.Button();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.button1.Location = new System.Drawing.Point(73, 100);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(284, 75);
			this.button1.TabIndex = 0;
			this.button1.Text = "Hasta(görüntüleme/kayıt/güncelleme/silme)";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.button2.Location = new System.Drawing.Point(73, 21);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(284, 73);
			this.button2.TabIndex = 0;
			this.button2.Text = "Doktor(görüntüleme/kayıt/güncelleme/silme)";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.button3.Location = new System.Drawing.Point(73, 181);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(284, 67);
			this.button3.TabIndex = 0;
			this.button3.Text = "Randevu(görüntüleme/oluşturma/güncelleme/silme)";
			this.button3.UseVisualStyleBackColor = false;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			this.button4.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.button4.Location = new System.Drawing.Point(7, 398);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(350, 43);
			this.button4.TabIndex = 1;
			this.button4.Text = "RAPORLAR";
			this.button4.UseVisualStyleBackColor = false;
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// button5
			// 
			this.button5.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.button5.Location = new System.Drawing.Point(73, 254);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(284, 66);
			this.button5.TabIndex = 2;
			this.button5.Text = "Tıbbi Kayıt(görüntüleme/oluşturma/güncelleme/silme)";
			this.button5.UseVisualStyleBackColor = false;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.groupBox1.Controls.Add(this.pictureBox5);
			this.groupBox1.Controls.Add(this.pictureBox4);
			this.groupBox1.Controls.Add(this.pictureBox3);
			this.groupBox1.Controls.Add(this.pictureBox2);
			this.groupBox1.Controls.Add(this.pictureBox1);
			this.groupBox1.Controls.Add(this.button6);
			this.groupBox1.Controls.Add(this.button2);
			this.groupBox1.Controls.Add(this.button5);
			this.groupBox1.Controls.Add(this.button3);
			this.groupBox1.Controls.Add(this.button1);
			this.groupBox1.Controls.Add(this.button4);
			this.groupBox1.ForeColor = System.Drawing.SystemColors.MenuText;
			this.groupBox1.Location = new System.Drawing.Point(13, -3);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(363, 450);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Menü";
			// 
			// pictureBox5
			// 
			this.pictureBox5.Image = global::softITo_hospital.Properties.Resources.WhatsApp_Görsel_2025_06_04_saat_13_45_05_c0e1ab29;
			this.pictureBox5.Location = new System.Drawing.Point(7, 326);
			this.pictureBox5.Name = "pictureBox5";
			this.pictureBox5.Size = new System.Drawing.Size(60, 66);
			this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox5.TabIndex = 4;
			this.pictureBox5.TabStop = false;
			// 
			// pictureBox4
			// 
			this.pictureBox4.Image = global::softITo_hospital.Properties.Resources.WhatsApp_Görsel_2025_06_04_saat_13_43_52_76b5a75c;
			this.pictureBox4.Location = new System.Drawing.Point(7, 254);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new System.Drawing.Size(60, 66);
			this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox4.TabIndex = 4;
			this.pictureBox4.TabStop = false;
			// 
			// pictureBox3
			// 
			this.pictureBox3.Image = global::softITo_hospital.Properties.Resources.WhatsApp_Görsel_2025_06_04_saat_13_42_04_26310409;
			this.pictureBox3.Location = new System.Drawing.Point(7, 181);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(60, 67);
			this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox3.TabIndex = 4;
			this.pictureBox3.TabStop = false;
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = global::softITo_hospital.Properties.Resources.WhatsApp_Görsel_2025_06_04_saat_13_46_11_09e607aa;
			this.pictureBox2.Location = new System.Drawing.Point(7, 100);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(60, 75);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox2.TabIndex = 4;
			this.pictureBox2.TabStop = false;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = global::softITo_hospital.Properties.Resources.WhatsApp_Görsel_2025_06_04_saat_13_45_42_08082271;
			this.pictureBox1.Location = new System.Drawing.Point(7, 21);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(60, 73);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 4;
			this.pictureBox1.TabStop = false;
			// 
			// button6
			// 
			this.button6.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.button6.Location = new System.Drawing.Point(73, 326);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(284, 66);
			this.button6.TabIndex = 3;
			this.button6.Text = "Test(kan/idrar/tansiyon)";
			this.button6.UseVisualStyleBackColor = false;
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// button7
			// 
			this.button7.BackColor = System.Drawing.SystemColors.HotTrack;
			this.button7.Location = new System.Drawing.Point(67, 382);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(69, 27);
			this.button7.TabIndex = 4;
			this.button7.Text = "Gönder";
			this.button7.UseVisualStyleBackColor = false;
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(414, 18);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(74, 16);
			this.label1.TabIndex = 4;
			this.label1.Text = "Doktor İsmi";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(414, 46);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(98, 16);
			this.label2.TabIndex = 4;
			this.label2.Text = "Doktor Soyismi";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(414, 75);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(71, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "Giriş Tarihi";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(415, 107);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(73, 16);
			this.label4.TabIndex = 4;
			this.label4.Text = "Çıkış Tarihi";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(527, 13);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(100, 22);
			this.textBox1.TabIndex = 5;
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(527, 40);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(100, 22);
			this.textBox2.TabIndex = 5;
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Location = new System.Drawing.Point(527, 69);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(100, 22);
			this.dateTimePicker1.TabIndex = 6;
			// 
			// dateTimePicker2
			// 
			this.dateTimePicker2.Location = new System.Drawing.Point(527, 101);
			this.dateTimePicker2.Name = "dateTimePicker2";
			this.dateTimePicker2.Size = new System.Drawing.Size(100, 22);
			this.dateTimePicker2.TabIndex = 6;
			// 
			// button8
			// 
			this.button8.Location = new System.Drawing.Point(576, 130);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(50, 23);
			this.button8.TabIndex = 7;
			this.button8.Text = "Ekle";
			this.button8.UseVisualStyleBackColor = true;
			this.button8.Click += new System.EventHandler(this.button8_Click);
			// 
			// button9
			// 
			this.button9.BackColor = System.Drawing.SystemColors.Info;
			this.button9.Location = new System.Drawing.Point(16, 218);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(139, 49);
			this.button9.TabIndex = 8;
			this.button9.Text = "Doktoru olmayan randevulü hastaları getir";
			this.button9.UseVisualStyleBackColor = false;
			this.button9.Click += new System.EventHandler(this.button9_Click);
			// 
			// dataGridView1
			// 
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Location = new System.Drawing.Point(390, 159);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.RowHeadersWidth = 51;
			this.dataGridView1.RowTemplate.Height = 24;
			this.dataGridView1.Size = new System.Drawing.Size(237, 121);
			this.dataGridView1.TabIndex = 9;
			this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
			// 
			// button10
			// 
			this.button10.BackColor = System.Drawing.SystemColors.Info;
			this.button10.Location = new System.Drawing.Point(16, 156);
			this.button10.Name = "button10";
			this.button10.Size = new System.Drawing.Size(139, 56);
			this.button10.TabIndex = 10;
			this.button10.Text = "Kayıt Yaptırmamış Hastaları Getir";
			this.button10.UseVisualStyleBackColor = false;
			this.button10.Click += new System.EventHandler(this.button10_Click);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(390, 321);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(70, 16);
			this.label5.TabIndex = 11;
			this.label5.Text = "Hasta İsmi";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(387, 355);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(94, 16);
			this.label6.TabIndex = 11;
			this.label6.Text = "Hasta Soyismi";
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(510, 318);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(100, 22);
			this.textBox3.TabIndex = 12;
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(510, 352);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(100, 22);
			this.textBox4.TabIndex = 12;
			// 
			// comboBox1
			// 
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Location = new System.Drawing.Point(510, 390);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(99, 24);
			this.comboBox1.TabIndex = 13;
			this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(390, 390);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(44, 16);
			this.label7.TabIndex = 14;
			this.label7.Text = "Mesaj";
			// 
			// button11
			// 
			this.button11.BackColor = System.Drawing.SystemColors.Info;
			this.button11.Location = new System.Drawing.Point(16, 27);
			this.button11.Name = "button11";
			this.button11.Size = new System.Drawing.Size(139, 42);
			this.button11.TabIndex = 15;
			this.button11.Text = "Randevuleri Olan Hastalar";
			this.button11.UseVisualStyleBackColor = false;
			this.button11.Click += new System.EventHandler(this.button11_Click);
			// 
			// button12
			// 
			this.button12.BackColor = System.Drawing.SystemColors.Info;
			this.button12.Location = new System.Drawing.Point(16, 90);
			this.button12.Name = "button12";
			this.button12.Size = new System.Drawing.Size(139, 50);
			this.button12.TabIndex = 16;
			this.button12.Text = "Randevuları Olan Doktorlar";
			this.button12.UseVisualStyleBackColor = false;
			this.button12.Click += new System.EventHandler(this.button12_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.groupBox2.Controls.Add(this.textBox5);
			this.groupBox2.Controls.Add(this.Mesaj);
			this.groupBox2.Controls.Add(this.button11);
			this.groupBox2.Controls.Add(this.button12);
			this.groupBox2.Controls.Add(this.button10);
			this.groupBox2.Controls.Add(this.button9);
			this.groupBox2.Controls.Add(this.button7);
			this.groupBox2.Location = new System.Drawing.Point(633, 13);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(167, 434);
			this.groupBox2.TabIndex = 17;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Günlük Kontroller";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(390, 287);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(155, 16);
			this.label8.TabIndex = 18;
			this.label8.Text = "Kayıt Durumunu Güncelle";
			// 
			// button13
			// 
			this.button13.BackColor = System.Drawing.SystemColors.HotTrack;
			this.button13.Location = new System.Drawing.Point(551, 287);
			this.button13.Name = "button13";
			this.button13.Size = new System.Drawing.Size(76, 23);
			this.button13.TabIndex = 19;
			this.button13.Text = "Kayıt Durumu";
			this.button13.UseVisualStyleBackColor = false;
			this.button13.Click += new System.EventHandler(this.button13_Click);
			// 
			// Mesaj
			// 
			this.Mesaj.FormattingEnabled = true;
			this.Mesaj.ItemHeight = 16;
			this.Mesaj.Location = new System.Drawing.Point(16, 292);
			this.Mesaj.Name = "Mesaj";
			this.Mesaj.Size = new System.Drawing.Size(125, 20);
			this.Mesaj.TabIndex = 17;
			// 
			// button14
			// 
			this.button14.Location = new System.Drawing.Point(393, 130);
			this.button14.Name = "button14";
			this.button14.Size = new System.Drawing.Size(75, 23);
			this.button14.TabIndex = 20;
			this.button14.Text = "Temizle";
			this.button14.UseVisualStyleBackColor = true;
			this.button14.Click += new System.EventHandler(this.button14_Click);
			// 
			// textBox5
			// 
			this.textBox5.Location = new System.Drawing.Point(16, 319);
			this.textBox5.Multiline = true;
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(151, 57);
			this.textBox5.TabIndex = 18;
			// 
			// Sekreter_İşlemleri
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ControlDark;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.button14);
			this.Controls.Add(this.button13);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.textBox4);
			this.Controls.Add(this.textBox3);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.dataGridView1);
			this.Controls.Add(this.button8);
			this.Controls.Add(this.dateTimePicker2);
			this.Controls.Add(this.dateTimePicker1);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.groupBox1);
			this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.Name = "Sekreter_İşlemleri";
			this.Text = "Sekreter_İşlemleri";
			this.Load += new System.EventHandler(this.Sekreter_İşlemleri_Load);
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.DateTimePicker dateTimePicker2;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.Button button10;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.PictureBox pictureBox5;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.ComponentModel.BackgroundWorker backgroundWorker1;
		private System.Windows.Forms.Button button11;
		private System.Windows.Forms.Button button12;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Button button13;
		private System.Windows.Forms.ListBox Mesaj;
		private System.Windows.Forms.Button button14;
		private System.Windows.Forms.TextBox textBox5;
	}
}