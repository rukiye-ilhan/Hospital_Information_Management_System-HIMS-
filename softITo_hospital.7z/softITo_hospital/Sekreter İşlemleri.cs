﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace softITo_hospital
{
	public partial class Sekreter_İşlemleri : Form
	{
		db_hospitalEntities con = new db_hospitalEntities();
		public Sekreter_İşlemleri()
		{
			InitializeComponent();
			this.BackgroundImage = Image.FromFile(@"C:\Users\LENOVO\Desktop\WhatsApp Görsel 2025-06-01 saat 18.30.22_b23a8557.jpg");
			this.BackgroundImageLayout = ImageLayout.Stretch;
			
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Hastalar hastalar  =  new Hastalar();
			hastalar.Show();
			this.Hide();

		}

		private void button2_Click(object sender, EventArgs e)
		{
			Doktorlar doktorlar = new Doktorlar();
			doktorlar.Show();
			this.Hide();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			Randevuler randevular = new Randevuler();
			randevular.Show();
			this.Hide();
			/*
			Anasayfa anasayfa = new Anasayfa();
			anasayfa.Show();
			this.Hide();*/
		}

		private void button5_Click(object sender, EventArgs e)
		{
			HastaTıbiTakip hastaTıbiTakip =  new HastaTıbiTakip();
			hastaTıbiTakip.Show();
			this.Hide();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			Anasayfa anasayfa = new Anasayfa();
			anasayfa.Show();
			this.Hide();
		}

		private void button11_Click(object sender, EventArgs e)
		{
			var sonuc = con.GetTodayAppointments().ToList();
			dataGridView1.DataSource = sonuc;
		}

		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0)
			{
				DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
				textBox4.Text = row.Cells["HastaSoyadi"].Value.ToString();
				textBox3.Text = row.Cells["HastaAdi"].Value.ToString(); 
				textBox2.Text = row.Cells["DoktorSoyadi"].Value.ToString();
				textBox1.Text = row.Cells["DoktorAdi"].Value.ToString();

			}
		}

		int p_id = 0;
		int d_id = 0;
		private void button10_Click(object sender, EventArgs e)
		{

			var sonuc = con.GetUnregisteredPatients().ToList();
			dataGridView1.DataSource = sonuc;
		}



	
		private void button13_Click(object sender, EventArgs e)
		{
			//Patient p = new Patient();
			string hastaAdi = textBox3.Text;
			string HastaSoyadi = textBox4.Text;


			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("GetPatientId", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					// Parametreleri ekle
					cmd.Parameters.AddWithValue("@HastaAdi", hastaAdi);
					cmd.Parameters.AddWithValue("@HastaSoyadi", HastaSoyadi);

					con.Open();

					// ExecuteScalar() tek bir değer döndürürse kullanılır
					object result = cmd.ExecuteScalar();

					if (result != null)
					{
						p_id = Convert.ToInt32(result);
					}
				}
			}
			//doctorıd getiren proc
			string DoktorAdi = textBox1.Text;
			string DoktorSoyadi = textBox2.Text;


			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("GetDoctorId", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					// Parametreleri ekle
					cmd.Parameters.AddWithValue("@DoktorAdi", DoktorAdi);
					cmd.Parameters.AddWithValue("@DoktorSoyadi", DoktorSoyadi);

					con.Open();

					// ExecuteScalar() tek bir değer döndürürse kullanılır
					object result = cmd.ExecuteScalar();

					if (result != null)
					{
						d_id = Convert.ToInt32(result);
					}
				}
			}

			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("UpdateKayitDurumu", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					// Parametreleri ekle
					cmd.Parameters.AddWithValue("@PatientId", p_id);
					cmd.Parameters.AddWithValue("@DoctorId", d_id);


					SqlDataAdapter da = new SqlDataAdapter(cmd);
					DataTable dt = new DataTable();
					con.Open();
					da.Fill(dt);
				}
			}
			MessageBox.Show("Hasta Randevu Öncesi Kayıt Yaptırmıştır.kayıt Durumu Güncellenmiştir");


			//hasta ve doktor ismine  ve soyismine denk gelen patientıd ve doctorıd bilgilerini almam gerekir proc'a parametre olarak eklme gerekiyor
			//patientıd getiren proc



		}

		private void button12_Click(object sender, EventArgs e)
		{
			var sonuc = con.GetUnregisteredPatients().ToList();
			dataGridView1.DataSource = sonuc;
		}

		private void button9_Click(object sender, EventArgs e)
		{
			string HastaAdi = textBox3.Text;
			string HastaSoyadi = textBox4.Text;

			var sonuc = con.GetDoktorDurumu111().ToList();
			dataGridView1.DataSource = sonuc;
			//doktoru olmayan randevulu hastalar önce bugünün tğm doktorlarını getiren procu al ve lsiteye koy listeden arama yapsın varsa var toksa yok desin yok olanalrada mesaj atsın
			/*using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("GetDoktorDurumu111", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					// Parametreleri ekle
					cmd.Parameters.AddWithValue("@HastaAdi", HastaAdi);
					cmd.Parameters.AddWithValue("@HastaSoyadi", HastaSoyadi);


					SqlDataAdapter da = new SqlDataAdapter(cmd);
					DataTable dt = new DataTable();
					con.Open();
					da.Fill(dt);
					dataGridView1.DataSource = dt;
				}
			}*/



		}

		private void Sekreter_İşlemleri_Load(object sender, EventArgs e)
		{

			comboBox1.Items.Add("Doktorunuz burada, muayene olabilirsiniz.");
			comboBox1.Items.Add("Bugün doktorunuz yok.");
			comboBox1.Items.Add("Hastane şu anda kapalıdır.");
			comboBox1.Items.Add("Kayıt yaptırmanız gerekmektedir.");
			comboBox1.Items.Add("Randevunuz bulunmamaktadır.");

		}
		string secilenMesaj = "";
		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			secilenMesaj = comboBox1.SelectedItem.ToString();
			//Mesaj.Items.Add(secilenMesaj);
			textBox5.Text = secilenMesaj;
		}

		private void button7_Click(object sender, EventArgs e)
		{
	
			if (secilenMesaj != null)
			{
				MessageBox.Show($"Mesajınız {textBox5.Text} başarıyla gönderildi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
				Mesaj.Items.Clear(); // Gönderildikten sonra temizlenebilir
			}
			else
			{
				MessageBox.Show("Gönderecek mesaj yok.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
		}

		private void button8_Click(object sender, EventArgs e)
		{
			string doktorAd = textBox1.Text;
			string doktorSoyad = textBox2.Text;
			DateTime gelisTarihi = dateTimePicker1.Value;
			DateTime gidisTarihi = dateTimePicker2.Value;

			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01;Database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("DoktorHareketleriEkle", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					cmd.Parameters.AddWithValue("@Ad", doktorAd);
					cmd.Parameters.AddWithValue("@Soyad", doktorSoyad);
					cmd.Parameters.AddWithValue("@GelisTarihi", gelisTarihi);
					cmd.Parameters.AddWithValue("@GidisTarihi", gidisTarihi);

					con.Open();
					cmd.ExecuteNonQuery();
				}
			}

			MessageBox.Show("Doktor hareketi başarıyla eklendi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void button14_Click(object sender, EventArgs e)
		{
			foreach (Control control in this.Controls)
			{
				if (control is TextBox)
				{
					((TextBox)control).Clear();
				}
			}

		}

		private void button6_Click(object sender, EventArgs e)
		{
			HastaTıbiTakip hastaTıbiTakip = new HastaTıbiTakip();
			hastaTıbiTakip.Show();
			this.Hide();
		}
	}
}
