﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System;




namespace softITo_hospital
{
	public partial class TeshisTedaviReceteIslemleri : Form
	{
		db_hospitalEntities con = new db_hospitalEntities();

		public TeshisTedaviReceteIslemleri()
		{
			InitializeComponent();
		}


		private void button5_Click(object sender, EventArgs e)
		{
			Doktor_İşlemleri doktor_İşlemleri = new Doktor_İşlemleri();
			doktor_İşlemleri.Show();
			this.Hide();
		}

		private void VeriGetirTıbbi()
		{
			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01;database=db_hospital;Integrated Security=true"))
			{
				string sorgu = "SELECT * FROM Prescriptions"; // veya istediğin özel sorgu
				SqlDataAdapter da = new SqlDataAdapter(sorgu, con);
				DataTable dt = new DataTable();
				da.Fill(dt);
				dataGridView1.DataSource = dt; // DataGridView'in ismini buraya yaz
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			var sonuc = con.GetMedicalInfo().ToList();
			dataGridView1.DataSource = sonuc;
		}

		private void TeshisTedaviReceteIslemleri_Load(object sender, EventArgs e)
		{
			comboBox1.Items.Add("Hipertansiyon");
			comboBox1.Items.Add("Şeker hastalığı");
			comboBox1.Items.Add("Depresyon");
			comboBox1.Items.Add("'Migren'");
			comboBox1.Items.Add("'Anemi'");
			comboBox1.Items.Add("'Gastrit'");
			comboBox1.Items.Add("'Kolesterol'");
			comboBox1.Items.Add("'Alerjik rinit'");
			comboBox1.Items.Add("'Cilt enfeksiyonu'");
			comboBox1.Items.Add("'Böbrek taşı'");
			comboBox1.Items.Add("'Kırık şüphesi'");
			comboBox1.Items.Add("'Kansızlık'");
			comboBox1.Items.Add("'Sırt ağrısı'");
			comboBox1.Items.Add("'Bronşit'");
			comboBox1.Items.Add("'Hipotiroidi'");

			comboBox2.Items.Add("Tansiyon ilacı reçete edildi");
			comboBox2.Items.Add("Diyet ve ilaç tedavisi başlatıldı");
			comboBox2.Items.Add("Ağrı kesici tedavi verildi");
			comboBox2.Items.Add("Demir takviyesi önerildi");
			comboBox2.Items.Add("Antiasit ilaç başlandı");
			comboBox2.Items.Add("Diyet ve statin verildi");
			comboBox2.Items.Add("Antihistaminik yazıldı");
			comboBox2.Items.Add("Antibiyotik tedavisi uygulandı");
			comboBox2.Items.Add("drar söktürücü önerildi");
			comboBox2.Items.Add("Röntgen istendi");
			comboBox2.Items.Add("Kan tahlili sonucu değerlendirildi'");
			comboBox2.Items.Add("Fizik tedaviye yönlendirildi");
			comboBox2.Items.Add("Psikiyatri kontrolü önerildi");
			comboBox2.Items.Add("Nebulizatör tedavisi başlandı");
			comboBox2.Items.Add("Levotiroksin başlandı");

		}

		string secilenMesajTeshis = "";
		string secilenMesajTedavi = "";


		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			secilenMesajTeshis = comboBox1.SelectedItem.ToString();
			//Mesaj.Items.Add(secilenMesaj);
			textBox5.Text = secilenMesajTeshis;
			//secilenMesajTeshis = textBox5.Text;
		}
		private void textBox5_TextChanged(object sender, EventArgs e)
		{
			secilenMesajTeshis = textBox5.Text;
		}

		private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
		{
			secilenMesajTedavi = comboBox2.SelectedItem.ToString();
			//Mesaj.Items.Add(secilenMesaj);
			textBox6.Text = secilenMesajTedavi;
			//secilenMesajTedavi = textBox6.Text;
		}
		private void textBox6_TextChanged(object sender, EventArgs e)
		{
			secilenMesajTedavi = textBox6.Text;
		}




		int record_id = 0;
		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0)
			{
				DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
				textBox1.Text = row.Cells["HastaAdi"].Value.ToString();
				textBox2.Text = row.Cells["HastaSoyadi"].Value.ToString();
				textBox3.Text = row.Cells["DoktorAdi"].Value.ToString();
				textBox4.Text = row.Cells["DoktorSoyadi"].Value.ToString();
				record_id = Convert.ToInt32(row.Cells["RecordId"].Value.ToString());

			}
		}



		int p_id = 0;
		int d_id = 0;


		private void button6_Click(object sender, EventArgs e)
		{

			MessageBox.Show($"{secilenMesajTeshis}");
			MessageBox.Show($"{secilenMesajTedavi}");
			//Patient p = new Patient();
			string hastaAdi = textBox1.Text;
			string HastaSoyadi = textBox2.Text;


			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("GetPatientId", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					// Parametreleri ekle
					cmd.Parameters.AddWithValue("@HastaAdi", hastaAdi);
					cmd.Parameters.AddWithValue("@HastaSoyadi", HastaSoyadi);

					con.Open();

					// ExecuteScalar() tek bir değer döndürürse kullanılır
					object result = cmd.ExecuteScalar();

					if (result != null)
					{
						p_id = Convert.ToInt32(result);
					}
				}
			}
			//doctorıd getiren proc
			string DoktorAdi = textBox3.Text;
			string DoktorSoyadi = textBox4.Text;


			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("GetDoctorId", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					// Parametreleri ekle
					cmd.Parameters.AddWithValue("@DoktorAdi", DoktorAdi);
					cmd.Parameters.AddWithValue("@DoktorSoyadi", DoktorSoyadi);

					con.Open();

					// ExecuteScalar() tek bir değer döndürürse kullanılır
					object result = cmd.ExecuteScalar();

					if (result != null)
					{
						d_id = Convert.ToInt32(result);
					}
				}
			}
			DateTime record_date = DateTime.Now;

			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("AddMedicalRecord", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					// Parametreleri ekle
					cmd.Parameters.AddWithValue("@PatientId", p_id);
					cmd.Parameters.AddWithValue("@DoctorId", d_id);
					cmd.Parameters.AddWithValue("@RecordDate", record_date);
					cmd.Parameters.AddWithValue("@Diagnosis", secilenMesajTeshis);
					cmd.Parameters.AddWithValue("@Treatment", secilenMesajTedavi);


					SqlDataAdapter da = new SqlDataAdapter(cmd);
					DataTable dt = new DataTable();
					con.Open();
					da.Fill(dt);

					//dataGridView1.DataSource = dt;
				}
			}
			MessageBox.Show("Hasta'nın medical kayıt bilgileri girilmiştir. ");
			VeriGetirTıbbi();





		}

		private void button7_Click(object sender, EventArgs e)
		{
			MessageBox.Show($"{secilenMesajTeshis}");
			MessageBox.Show($"{secilenMesajTedavi}");
			//Patient p = new Patient();
			string hastaAdi = textBox1.Text;
			string HastaSoyadi = textBox2.Text;


			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("GetPatientId", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					// Parametreleri ekle
					cmd.Parameters.AddWithValue("@HastaAdi", hastaAdi);
					cmd.Parameters.AddWithValue("@HastaSoyadi", HastaSoyadi);

					con.Open();

					// ExecuteScalar() tek bir değer döndürürse kullanılır
					object result = cmd.ExecuteScalar();

					if (result != null)
					{
						p_id = Convert.ToInt32(result);
					}
				}
			}
			//doctorıd getiren proc
			string DoktorAdi = textBox3.Text;
			string DoktorSoyadi = textBox4.Text;


			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("GetDoctorId", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					// Parametreleri ekle
					cmd.Parameters.AddWithValue("@DoktorAdi", DoktorAdi);
					cmd.Parameters.AddWithValue("@DoktorSoyadi", DoktorSoyadi);

					con.Open();

					// ExecuteScalar() tek bir değer döndürürse kullanılır
					object result = cmd.ExecuteScalar();

					if (result != null)
					{
						d_id = Convert.ToInt32(result);
					}
				}
			}
			DateTime record_date = DateTime.Now;

			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("UpdateMedicalRecord", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					// Parametreleri ekle
					cmd.Parameters.AddWithValue("RecordId", record_id);
					cmd.Parameters.AddWithValue("@PatientId", p_id);
					cmd.Parameters.AddWithValue("@DoctorId", d_id);
					//cmd.Parameters.AddWithValue("@RecordDate", record_date);
					cmd.Parameters.AddWithValue("@Diagnosis", secilenMesajTeshis);
					cmd.Parameters.AddWithValue("@Treatment", secilenMesajTedavi);


					SqlDataAdapter da = new SqlDataAdapter(cmd);
					DataTable dt = new DataTable();
					con.Open();
					da.Fill(dt);

					//dataGridView1.DataSource = dt;
				}
			}
			MessageBox.Show("Hasta'nın medical kayıt bilgileri Güncellenmiştir. ");
			VeriGetirTıbbi();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			string word = textBox7.Text;
			using (var context = new db_hospitalEntities())
			{
				var wordParam = new SqlParameter("@word", word); // DÜZELTİLDİ

				var results = context.Database
					.SqlQuery<string>("EXEC SearchDiagnosisByTreatmentWord @word", wordParam)
					.ToList();

				textBox8.Text = string.Join(Environment.NewLine, results);
			}
		}

		//Reçete İşlemleri
		private void VeriGetirRecete()
		{
			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01;database=db_hospital;Integrated Security=true"))
			{
				string sorgu = "SELECT * FROM Prescriptions"; // veya istediğin özel sorgu
				SqlDataAdapter da = new SqlDataAdapter(sorgu, con);
				DataTable dt = new DataTable();
				da.Fill(dt);
				dataGridView2.DataSource = dt; // DataGridView'in ismini buraya yaz
			}
		}


		private void button8_Click(object sender, EventArgs e)
		{
			var sonuc = con.ListPrescriptions().ToList();
			dataGridView2.DataSource = sonuc;

		}

		int prescriptions_id = 0;
		private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0)
			{
				DataGridViewRow row = dataGridView2.Rows[e.RowIndex];
				textBox9.Text = row.Cells["MedicineName"].Value.ToString();
				textBox10.Text = row.Cells["Dosage"].Value.ToString();
				textBox11.Text = row.Cells["DurationDays"].Value.ToString();
				prescriptions_id = Convert.ToInt32(row.Cells["PrescriptionId"].Value.ToString());
				record_id = Convert.ToInt32(row.Cells["RecordId"].Value.ToString());


			}

		}


		private void button3_Click(object sender, EventArgs e)
		{
			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("AddPrescription", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					// Parametreleri ekle
					cmd.Parameters.AddWithValue("@RecordId", record_id);
					cmd.Parameters.AddWithValue("@MedicineName", textBox9.Text);
					cmd.Parameters.AddWithValue("@Dosage", textBox10.Text);
					cmd.Parameters.AddWithValue("@DurationDays", textBox11.Text);


					SqlDataAdapter da = new SqlDataAdapter(cmd);
					DataTable dt = new DataTable();
					con.Open();
					da.Fill(dt);

					//dataGridView2.DataSource = dt;
				}
			}
			MessageBox.Show("Hasta'ya ait reçete  oluşturulmuştur. ");
			VeriGetirRecete();


		}

		private void button4_Click(object sender, EventArgs e)
		{
			using (SqlConnection con = new SqlConnection("Server=DESKTOP-GI1C2ED\\SQLEXPRESS01 ;database=db_hospital;Integrated Security=true"))
			{
				using (SqlCommand cmd = new SqlCommand("UpdatePrescription", con))
				{
					cmd.CommandType = CommandType.StoredProcedure;

					// Parametreleri ekle
					cmd.Parameters.AddWithValue("PrescriptionId", prescriptions_id);
					//cmd.Parameters.AddWithValue("@RecordId", record_id);
					cmd.Parameters.AddWithValue("@MedicineName", textBox9.Text);
					cmd.Parameters.AddWithValue("@Dosage", textBox10.Text);
					cmd.Parameters.AddWithValue("@DurationDays", textBox11.Text);



					SqlDataAdapter da = new SqlDataAdapter(cmd);
					DataTable dt = new DataTable();
					con.Open();
					da.Fill(dt);
					//dataGridView1.DataSource = con.UpdatePrescription().ToList();
				}
			}
			MessageBox.Show("Hasta'nın reçete kayıt bilgileri Güncellenmiştir. ");
			VeriGetirRecete();
		}
		//dataGridView2.DataSource = dt;
		private void ClearAllTextBoxes(Control parent)
		{
			foreach (Control control in parent.Controls)
			{
				if (control is TextBox)
				{
					((TextBox)control).Clear();
				}
				else if (control.HasChildren)
				{
					ClearAllTextBoxes(control); // recursive çağrı
				}
			}
		}

		private void button9_Click(object sender, EventArgs e)
		{
			ClearAllTextBoxes(this);
		}






		private void label2_Click(object sender, EventArgs e)
		{

		}


	}
}
